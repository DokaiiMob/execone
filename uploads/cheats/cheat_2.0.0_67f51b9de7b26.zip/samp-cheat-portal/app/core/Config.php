<?php

namespace App\Core;

class Config
{
    private static $instance = null;
    private $configs = [];

    private function __construct()
    {
        // Load main config
        $this->configs = require __DIR__ . '/../config/config.php';

        // Load other config files if they exist
        $configFiles = glob(__DIR__ . '/../config/*.php');
        foreach ($configFiles as $file) {
            if (basename($file) !== 'config.php') {
                $key = basename($file, '.php');
                $this->configs[$key] = require $file;
            }
        }
    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function get($key, $default = null)
    {
        return $this->getValue($this->configs, $key, $default);
    }

    public function set($key, $value)
    {
        $keys = explode('.', $key);
        $config = &$this->configs;

        while (count($keys) > 1) {
            $current = array_shift($keys);
            if (!isset($config[$current]) || !is_array($config[$current])) {
                $config[$current] = [];
            }
            $config = &$config[$current];
        }

        $config[array_shift($keys)] = $value;
        return $this;
    }

    private function getValue($array, $key, $default = null)
    {
        if (is_null($key)) {
            return $array;
        }

        if (isset($array[$key])) {
            return $array[$key];
        }

        foreach (explode('.', $key) as $segment) {
            if (!is_array($array) || !array_key_exists($segment, $array)) {
                return $default;
            }
            $array = $array[$segment];
        }

        return $array;
    }

    public function all()
    {
        return $this->configs;
    }
}
