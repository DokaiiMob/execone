<?php

namespace App\Core;

use App\Core\Config;
use App\Core\Database;
use Bramus\Router\Router;
use Whoops\Run as Whoops;
use Whoops\Handler\PrettyPageHandler;

class App
{
    private static $instance = null;
    private $router;

    private function __construct()
    {
        // Check if session is started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Load configuration
        $config = Config::getInstance();

        // Set error reporting
        if ($config->get('site.debug', false)) {
            error_reporting(E_ALL);
            ini_set('display_errors', 1);

            // Use Whoops for error handling in debug mode
            $whoops = new Whoops();
            $whoops->pushHandler(new PrettyPageHandler());
            $whoops->register();
        } else {
            error_reporting(0);
            ini_set('display_errors', 0);
        }

        // Initialize router
        $this->router = new Router();

        // Apply global middlewares
        $this->applyGlobalMiddlewares();

        // Initialize database connection
        Database::getInstance();
    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function applyGlobalMiddlewares()
    {
        // CSRF Protection
        if (config('security.csrf_protection', true)) {
            $this->router->before('POST|PUT|DELETE', '/.*', function () {
                $requestToken = $_POST['csrf_token'] ?? '';
                if (!verify_csrf_token($requestToken)) {
                    flash('error', 'Invalid CSRF token. Please try again.');
                    redirect($_SERVER['HTTP_REFERER'] ?? '/');
                }
            });
        }

        // Authentication check for admin routes
        $this->router->before('GET|POST|PUT|DELETE', '/admin(/.*)?', function () {
            if (!isLoggedIn() || !isAdmin()) {
                flash('error', 'You do not have permission to access this area.');
                redirect('/login');
            }
        });

        // Authentication check for user dashboard routes
        $this->router->before('GET|POST|PUT|DELETE', '/dashboard(/.*)?', function () {
            if (!isLoggedIn()) {
                flash('error', 'Please log in to access your dashboard.');
                redirect('/login');
            }
        });
    }

    public function getRouter()
    {
        return $this->router;
    }

    public function registerRoutes()
    {
        // Include all route files
        $routeFiles = glob(__DIR__ . '/../routes/*.php');
        foreach ($routeFiles as $file) {
            require_once $file;
        }

        return $this;
    }

    public function run()
    {
        $this->router->run();
    }

    public function initializeDatabase()
    {
        $migrations = glob(__DIR__ . '/../database/migrations/*.php');
        sort($migrations);

        foreach ($migrations as $migration) {
            require_once $migration;

            $className = 'App\\Database\\Migrations\\' . basename($migration, '.php');
            $migrationInstance = new $className();

            if (method_exists($migrationInstance, 'up')) {
                $migrationInstance->up();
            }
        }

        return $this;
    }
}
