<?php

namespace App\Core;

use App\Core\Database;

abstract class Model
{
    protected $table;
    protected $primaryKey = 'id';
    protected $fillable = [];
    protected $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getAll()
    {
        $sql = "SELECT * FROM {$this->table}";
        return $this->db->select($sql);
    }

    public function find($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id LIMIT 1";
        return $this->db->selectOne($sql, ['id' => $id]);
    }

    public function findBy($column, $value)
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$column} = :value";
        return $this->db->select($sql, ['value' => $value]);
    }

    public function findOneBy($column, $value)
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$column} = :value LIMIT 1";
        return $this->db->selectOne($sql, ['value' => $value]);
    }

    public function create(array $data)
    {
        $filteredData = $this->filterData($data);
        return $this->db->insert($this->table, $filteredData);
    }

    public function update($id, array $data)
    {
        $filteredData = $this->filterData($data);
        return $this->db->update(
            $this->table,
            $filteredData,
            "{$this->primaryKey} = :id",
            ['id' => $id]
        );
    }

    public function delete($id)
    {
        return $this->db->delete(
            $this->table,
            "{$this->primaryKey} = :id",
            ['id' => $id]
        );
    }

    public function where($conditions, $params = [])
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$conditions}";
        return $this->db->select($sql, $params);
    }

    public function whereOne($conditions, $params = [])
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$conditions} LIMIT 1";
        return $this->db->selectOne($sql, $params);
    }

    public function count($conditions = null, $params = [])
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}";

        if ($conditions) {
            $sql .= " WHERE {$conditions}";
        }

        $result = $this->db->selectOne($sql, $params);
        return $result['count'] ?? 0;
    }

    protected function filterData(array $data)
    {
        if (empty($this->fillable)) {
            return $data;
        }

        return array_intersect_key($data, array_flip($this->fillable));
    }

    public function paginate($page = 1, $perPage = 10, $conditions = null, $params = [])
    {
        $sql = "SELECT * FROM {$this->table}";

        if ($conditions) {
            $sql .= " WHERE {$conditions}";
        }

        // Calculate offset
        $offset = ($page - 1) * $perPage;

        // Add limit and offset
        $sql .= " LIMIT {$perPage} OFFSET {$offset}";

        // Get the results
        $results = $this->db->select($sql, $params);

        // Count total records
        $totalSql = "SELECT COUNT(*) as count FROM {$this->table}";
        if ($conditions) {
            $totalSql .= " WHERE {$conditions}";
        }
        $totalResult = $this->db->selectOne($totalSql, $params);
        $total = $totalResult['count'] ?? 0;

        // Calculate total pages
        $totalPages = ceil($total / $perPage);

        return [
            'data' => $results,
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
            'has_more_pages' => $page < $totalPages,
            'next_page' => $page < $totalPages ? $page + 1 : null,
            'prev_page' => $page > 1 ? $page - 1 : null,
        ];
    }

    public function rawQuery($sql, $params = [])
    {
        return $this->db->select($sql, $params);
    }
}
