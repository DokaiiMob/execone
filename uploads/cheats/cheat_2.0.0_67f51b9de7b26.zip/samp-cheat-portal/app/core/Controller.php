<?php

namespace App\Core;

class Controller
{
    protected function view($name, $data = [])
    {
        // Extract data variables so they can be used directly in the view
        extract($data);

        // Get the view file path
        $viewPath = __DIR__ . '/../views/' . $name . '.php';

        // Check if the view file exists
        if (!file_exists($viewPath)) {
            throw new \Exception("View {$name} not found");
        }

        // Start output buffering
        ob_start();

        // Include the view file
        include $viewPath;

        // Get the contents of the output buffer and clean it
        $content = ob_get_clean();

        // Return the content
        return $content;
    }

    protected function render($name, $data = [])
    {
        // Render the view and output it directly
        echo $this->view($name, $data);
    }

    protected function renderWithLayout($viewName, $layoutName = 'layouts/main', $data = [])
    {
        // Add the content of the view to the data
        $data['content'] = $this->view($viewName, $data);

        // Render the layout with the data
        $this->render($layoutName, $data);
    }

    protected function json($data, $statusCode = 200)
    {
        // Set the content type to JSON
        header('Content-Type: application/json');

        // Set the HTTP status code
        http_response_code($statusCode);

        // Output the JSON encoded data
        echo json_encode($data);
        exit;
    }

    protected function getRequestMethod()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    protected function isGet()
    {
        return $this->getRequestMethod() === 'GET';
    }

    protected function isPost()
    {
        return $this->getRequestMethod() === 'POST';
    }

    protected function isPut()
    {
        return $this->getRequestMethod() === 'PUT';
    }

    protected function isDelete()
    {
        return $this->getRequestMethod() === 'DELETE';
    }

    protected function getPostData()
    {
        return $_POST;
    }

    protected function getQueryParams()
    {
        return $_GET;
    }

    protected function getJsonData()
    {
        $jsonData = file_get_contents('php://input');
        return json_decode($jsonData, true);
    }

    protected function redirect($url, $statusCode = 302)
    {
        header('Location: ' . $url, true, $statusCode);
        exit;
    }

    protected function back()
    {
        $this->redirect($_SERVER['HTTP_REFERER'] ?? '/');
    }

    protected function withInput(array $input)
    {
        $_SESSION['old'] = $input;
        return $this;
    }

    protected function withErrors(array $errors)
    {
        $_SESSION['errors'] = $errors;
        return $this;
    }

    protected function flashMessage($type, $message)
    {
        $_SESSION['flash'][$type] = $message;
        return $this;
    }
}
