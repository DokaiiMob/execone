<?php

namespace App\Core;

use App\Core\Database;

abstract class Migration
{
    protected $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    abstract public function up();

    abstract public function down();

    public function createTable($table, $fields, $primaryKey = 'id', $engine = 'InnoDB')
    {
        $this->db->createTable($table, $fields, $primaryKey, $engine);
    }

    public function dropTable($table)
    {
        $type = config('database.type', 'sqlite');

        if ($type === 'mysql') {
            $this->db->query("DROP TABLE IF EXISTS {$table}");
        } else {
            $this->db->query("DROP TABLE IF EXISTS {$table}");
        }
    }

    public function tableExists($table)
    {
        return $this->db->tableExists($table);
    }

    public function addColumn($table, $column, $definition)
    {
        $type = config('database.type', 'sqlite');

        if ($type === 'mysql') {
            $this->db->query("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
        } else {
            // SQLite does not support ADD COLUMN with constraints like NOT NULL without default values
            // So for SQLite we need to create a new table, copy the data, and drop the old table

            // Get the current table schema
            $tableInfo = $this->db->select("PRAGMA table_info({$table})");

            // Create column definitions for the new table
            $columnDefs = [];
            foreach ($tableInfo as $col) {
                $columnDefs[] = "{$col['name']} {$col['type']}";
            }

            // Add the new column
            $columnDefs[] = "{$column} {$definition}";

            // Create a temporary table
            $tempTable = "{$table}_temp";
            $this->db->query("CREATE TABLE {$tempTable} (" . implode(', ', $columnDefs) . ")");

            // Get the column names for the INSERT statement
            $columnNames = [];
            foreach ($tableInfo as $col) {
                $columnNames[] = $col['name'];
            }

            // Copy data from the old table to the new table
            $this->db->query("INSERT INTO {$tempTable} (" . implode(', ', $columnNames) . ") SELECT " . implode(', ', $columnNames) . " FROM {$table}");

            // Drop the old table
            $this->db->query("DROP TABLE {$table}");

            // Rename the temporary table to the original table name
            $this->db->query("ALTER TABLE {$tempTable} RENAME TO {$table}");
        }
    }

    public function dropColumn($table, $column)
    {
        $type = config('database.type', 'sqlite');

        if ($type === 'mysql') {
            $this->db->query("ALTER TABLE {$table} DROP COLUMN {$column}");
        } else {
            // SQLite does not support DROP COLUMN
            // So for SQLite we need to create a new table, copy the data, and drop the old table

            // Get the current table schema
            $tableInfo = $this->db->select("PRAGMA table_info({$table})");

            // Create column definitions for the new table (excluding the column to drop)
            $columnDefs = [];
            $columnNames = [];
            foreach ($tableInfo as $col) {
                if ($col['name'] !== $column) {
                    $columnDefs[] = "{$col['name']} {$col['type']}";
                    $columnNames[] = $col['name'];
                }
            }

            // Create a temporary table
            $tempTable = "{$table}_temp";
            $this->db->query("CREATE TABLE {$tempTable} (" . implode(', ', $columnDefs) . ")");

            // Copy data from the old table to the new table
            $this->db->query("INSERT INTO {$tempTable} (" . implode(', ', $columnNames) . ") SELECT " . implode(', ', $columnNames) . " FROM {$table}");

            // Drop the old table
            $this->db->query("DROP TABLE {$table}");

            // Rename the temporary table to the original table name
            $this->db->query("ALTER TABLE {$tempTable} RENAME TO {$table}");
        }
    }

    public function addIndex($table, $index, $columns)
    {
        $type = config('database.type', 'sqlite');

        if (is_array($columns)) {
            $columns = implode(', ', $columns);
        }

        if ($type === 'mysql') {
            $this->db->query("CREATE INDEX {$index} ON {$table} ({$columns})");
        } else {
            $this->db->query("CREATE INDEX IF NOT EXISTS {$index} ON {$table} ({$columns})");
        }
    }

    public function dropIndex($table, $index)
    {
        $type = config('database.type', 'sqlite');

        if ($type === 'mysql') {
            $this->db->query("DROP INDEX {$index} ON {$table}");
        } else {
            $this->db->query("DROP INDEX IF EXISTS {$index}");
        }
    }
}
