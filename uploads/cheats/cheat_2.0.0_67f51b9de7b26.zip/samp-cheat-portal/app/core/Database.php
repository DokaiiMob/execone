<?php

namespace App\Core;

use PDO;
use PDOException;
use App\Core\Config;

class Database
{
    private static $instance = null;
    private $pdo;
    private $inTransaction = false;

    private function __construct()
    {
        $config = Config::getInstance();
        $dbType = $config->get('database.type', 'sqlite');

        try {
            if ($dbType === 'mysql') {
                $dsn = 'mysql:host=' . $config->get('database.mysql.host') . ';';
                $dsn .= 'dbname=' . $config->get('database.mysql.database') . ';';
                $dsn .= 'charset=' . $config->get('database.mysql.charset') . ';';
                $dsn .= 'port=' . $config->get('database.mysql.port');

                $this->pdo = new PDO(
                    $dsn,
                    $config->get('database.mysql.username'),
                    $config->get('database.mysql.password'),
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                    ]
                );
            } else {
                $dbPath = $config->get('database.sqlite.database');
                $dbDir = dirname($dbPath);

                // Create directory if it doesn't exist
                if (!is_dir($dbDir)) {
                    mkdir($dbDir, 0755, true);
                }

                // Create the SQLite database file if it doesn't exist
                if (!file_exists($dbPath)) {
                    touch($dbPath);
                    chmod($dbPath, 0644);
                }

                $this->pdo = new PDO('sqlite:' . $dbPath, null, null, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);

                if ($config->get('database.sqlite.foreign_key_constraints')) {
                    $this->pdo->exec('PRAGMA foreign_keys = ON');
                }
            }
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getPdo()
    {
        return $this->pdo;
    }

    public function query($sql, $params = [])
    {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            throw new PDOException("Query Error: " . $e->getMessage());
        }
    }

    public function select($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }

    public function selectOne($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }

    public function insert($table, $data)
    {
        $columns = array_keys($data);
        $placeholders = array_map(function ($item) {
            return ':' . $item;
        }, $columns);

        $sql = "INSERT INTO {$table} (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";

        $stmt = $this->pdo->prepare($sql);

        foreach ($data as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }

        $stmt->execute();
        return $this->pdo->lastInsertId();
    }

    public function update($table, $data, $where, $whereParams = [])
    {
        $setFields = array_map(function ($item) {
            return "{$item} = :{$item}";
        }, array_keys($data));

        $sql = "UPDATE {$table} SET " . implode(', ', $setFields) . " WHERE {$where}";

        $stmt = $this->pdo->prepare($sql);

        foreach ($data as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }

        foreach ($whereParams as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }

        $stmt->execute();
        return $stmt->rowCount();
    }

    public function delete($table, $where, $whereParams = [])
    {
        $sql = "DELETE FROM {$table} WHERE {$where}";

        $stmt = $this->pdo->prepare($sql);

        foreach ($whereParams as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }

        $stmt->execute();
        return $stmt->rowCount();
    }

    public function beginTransaction()
    {
        if (!$this->inTransaction) {
            $this->pdo->beginTransaction();
            $this->inTransaction = true;
            return true;
        }
        return false;
    }

    public function commit()
    {
        if ($this->inTransaction) {
            $this->pdo->commit();
            $this->inTransaction = false;
            return true;
        }
        return false;
    }

    public function rollback()
    {
        if ($this->inTransaction) {
            $this->pdo->rollBack();
            $this->inTransaction = false;
            return true;
        }
        return false;
    }

    public function tableExists($table)
    {
        $config = Config::getInstance();
        $dbType = $config->get('database.type', 'sqlite');

        if ($dbType === 'mysql') {
            $sql = "SHOW TABLES LIKE ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$table]);
            return $stmt->rowCount() > 0;
        } else {
            $sql = "SELECT name FROM sqlite_master WHERE type='table' AND name=?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$table]);
            return $stmt->rowCount() > 0;
        }
    }

    public function createTable($table, $fields, $primaryKey, $engine = 'InnoDB')
    {
        $config = Config::getInstance();
        $dbType = $config->get('database.type', 'sqlite');

        $fieldDefinitions = [];

        foreach ($fields as $field => $definition) {
            $fieldDefinitions[] = "{$field} {$definition}";
        }

        $primaryKey = "PRIMARY KEY ({$primaryKey})";
        $fieldDefinitions[] = $primaryKey;

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (" . implode(', ', $fieldDefinitions) . ")";

        if ($dbType === 'mysql') {
            $sql .= " ENGINE={$engine} DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        }

        $this->pdo->exec($sql);
    }
}
