<?php

namespace App\Models;

use App\Core\Model;

class Subscription extends Model
{
    protected $table = 'subscriptions';
    protected $primaryKey = 'id';
    protected $fillable = [
        'user_id', 'plan', 'status', 'starts_at', 'expires_at',
        'payment_id', 'payment_method', 'amount_paid', 'auto_renew'
    ];

    // Get active subscriptions for a user
    public function getActiveForUser($userId)
    {
        $now = date('Y-m-d H:i:s');

        $sql = "SELECT * FROM {$this->table}
                WHERE user_id = :user_id
                AND status = 'active'
                AND starts_at <= :now
                AND expires_at >= :now
                ORDER BY expires_at DESC";

        return $this->db->select($sql, [
            'user_id' => $userId,
            'now' => $now
        ]);
    }

    // Get all subscriptions for a user
    public function getAllForUser($userId)
    {
        $sql = "SELECT * FROM {$this->table}
                WHERE user_id = :user_id
                ORDER BY created_at DESC";

        return $this->db->select($sql, [
            'user_id' => $userId
        ]);
    }

    // Get the latest active subscription for a user
    public function getLatestActiveForUser($userId)
    {
        $now = date('Y-m-d H:i:s');

        $sql = "SELECT * FROM {$this->table}
                WHERE user_id = :user_id
                AND status = 'active'
                AND starts_at <= :now
                AND expires_at >= :now
                ORDER BY expires_at DESC
                LIMIT 1";

        return $this->db->selectOne($sql, [
            'user_id' => $userId,
            'now' => $now
        ]);
    }

    // Create a new subscription
    public function createSubscription($userId, $plan, $paymentMethod, $amountPaid, $autoRenew = false)
    {
        $planDetails = config("subscription_plans.{$plan}");

        if (!$planDetails) {
            throw new \Exception("Invalid subscription plan");
        }

        $now = date('Y-m-d H:i:s');
        $duration = $planDetails['duration'] ?? 30; // Default to 30 days
        $expiresAt = date('Y-m-d H:i:s', strtotime("+{$duration} days"));

        return $this->create([
            'user_id' => $userId,
            'plan' => $plan,
            'status' => 'active',
            'starts_at' => $now,
            'expires_at' => $expiresAt,
            'payment_method' => $paymentMethod,
            'amount_paid' => $amountPaid,
            'auto_renew' => $autoRenew ? 1 : 0
        ]);
    }

    // Update a subscription status
    public function updateStatus($id, $status)
    {
        return $this->update($id, [
            'status' => $status
        ]);
    }

    // Cancel a subscription
    public function cancelSubscription($id)
    {
        return $this->update($id, [
            'status' => 'cancelled',
            'auto_renew' => 0
        ]);
    }

    // Extend a subscription
    public function extendSubscription($id, $days)
    {
        $subscription = $this->find($id);

        if (!$subscription) {
            return false;
        }

        $expiresAt = date('Y-m-d H:i:s', strtotime($subscription['expires_at'] . " +{$days} days"));

        return $this->update($id, [
            'expires_at' => $expiresAt
        ]);
    }

    // Check if a subscription is active
    public function isActive($id)
    {
        $subscription = $this->find($id);

        if (!$subscription) {
            return false;
        }

        $now = date('Y-m-d H:i:s');

        return $subscription['status'] === 'active' &&
               $subscription['starts_at'] <= $now &&
               $subscription['expires_at'] >= $now;
    }

    // Check if a user has an active subscription
    public function userHasActiveSubscription($userId)
    {
        $now = date('Y-m-d H:i:s');

        $sql = "SELECT COUNT(*) as count FROM {$this->table}
                WHERE user_id = :user_id
                AND status = 'active'
                AND starts_at <= :now
                AND expires_at >= :now";

        $result = $this->db->selectOne($sql, [
            'user_id' => $userId,
            'now' => $now
        ]);

        return $result['count'] > 0;
    }

    // Get subscriptions that are about to expire
    public function getAboutToExpire($days = 3)
    {
        $now = date('Y-m-d H:i:s');
        $future = date('Y-m-d H:i:s', strtotime("+{$days} days"));

        $sql = "SELECT * FROM {$this->table}
                WHERE status = 'active'
                AND expires_at BETWEEN :now AND :future
                AND auto_renew = 0
                ORDER BY expires_at";

        return $this->db->select($sql, [
            'now' => $now,
            'future' => $future
        ]);
    }

    // Get expired subscriptions
    public function getExpired()
    {
        $now = date('Y-m-d H:i:s');

        $sql = "SELECT * FROM {$this->table}
                WHERE status = 'active'
                AND expires_at < :now
                ORDER BY expires_at";

        return $this->db->select($sql, [
            'now' => $now
        ]);
    }

    // Get subscriptions by plan
    public function getByPlan($plan)
    {
        return $this->findBy('plan', $plan);
    }

    // Get active subscriptions by plan
    public function getActiveByPlan($plan)
    {
        $now = date('Y-m-d H:i:s');

        $sql = "SELECT * FROM {$this->table}
                WHERE plan = :plan
                AND status = 'active'
                AND starts_at <= :now
                AND expires_at >= :now
                ORDER BY expires_at";

        return $this->db->select($sql, [
            'plan' => $plan,
            'now' => $now
        ]);
    }
}
