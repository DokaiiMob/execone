<?php

namespace App\Models;

use App\Core\Model;

class User extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $fillable = [
        'username', 'email', 'password', 'role', 'email_verified',
        'email_verification_token', 'password_reset_token', 'hwid',
        'last_login', 'login_attempts', 'locked_until'
    ];

    public function findByEmail($email)
    {
        return $this->findOneBy('email', $email);
    }

    public function findByUsername($username)
    {
        return $this->findOneBy('username', $username);
    }

    public function findByPasswordResetToken($token)
    {
        return $this->findOneBy('password_reset_token', $token);
    }

    public function findByEmailVerificationToken($token)
    {
        return $this->findOneBy('email_verification_token', $token);
    }

    public function getSubscriptions($userId)
    {
        $sql = "SELECT s.* FROM subscriptions s WHERE s.user_id = :user_id ORDER BY s.created_at DESC";
        return $this->db->select($sql, ['user_id' => $userId]);
    }

    public function getActiveSubscription($userId)
    {
        $now = date('Y-m-d H:i:s');
        $sql = "SELECT s.* FROM subscriptions s
                WHERE s.user_id = :user_id
                AND s.status = 'active'
                AND s.starts_at <= :now
                AND s.expires_at >= :now
                ORDER BY s.expires_at DESC
                LIMIT 1";

        return $this->db->selectOne($sql, [
            'user_id' => $userId,
            'now' => $now
        ]);
    }

    public function isAdmin($userId)
    {
        $user = $this->find($userId);
        return $user && $user['role'] === 'admin';
    }

    public function isEmailVerified($userId)
    {
        $user = $this->find($userId);
        return $user && (int)$user['email_verified'] === 1;
    }

    public function isAccountLocked($userId)
    {
        $user = $this->find($userId);
        if (!$user) {
            return false;
        }

        if ($user['locked_until'] && $user['locked_until'] > date('Y-m-d H:i:s')) {
            return true;
        }

        return false;
    }

    public function incrementLoginAttempts($userId)
    {
        $user = $this->find($userId);
        if (!$user) {
            return false;
        }

        $attempts = (int)$user['login_attempts'] + 1;
        $maxAttempts = config('auth.max_login_attempts', 5);

        if ($attempts >= $maxAttempts) {
            $lockoutTime = config('auth.lockout_time', 300); // in seconds
            $lockedUntil = date('Y-m-d H:i:s', time() + $lockoutTime);

            return $this->update($userId, [
                'login_attempts' => $attempts,
                'locked_until' => $lockedUntil
            ]);
        }

        return $this->update($userId, [
            'login_attempts' => $attempts
        ]);
    }

    public function resetLoginAttempts($userId)
    {
        return $this->update($userId, [
            'login_attempts' => 0,
            'locked_until' => null
        ]);
    }

    public function updateLastLogin($userId)
    {
        return $this->update($userId, [
            'last_login' => date('Y-m-d H:i:s')
        ]);
    }

    public function updateHWID($userId, $hwid)
    {
        return $this->update($userId, [
            'hwid' => $hwid
        ]);
    }

    public function verifyEmail($userId)
    {
        return $this->update($userId, [
            'email_verified' => 1,
            'email_verification_token' => null
        ]);
    }

    public function setPasswordResetToken($userId, $token)
    {
        return $this->update($userId, [
            'password_reset_token' => $token
        ]);
    }

    public function clearPasswordResetToken($userId)
    {
        return $this->update($userId, [
            'password_reset_token' => null
        ]);
    }

    public function updatePassword($userId, $hashedPassword)
    {
        return $this->update($userId, [
            'password' => $hashedPassword,
            'password_reset_token' => null
        ]);
    }

    public function generateEmailVerificationToken()
    {
        return bin2hex(random_bytes(32));
    }

    public function generatePasswordResetToken()
    {
        return bin2hex(random_bytes(32));
    }
}
