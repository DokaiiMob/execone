<?php

namespace App\Models;

use App\Core\Model;

class CheatVersion extends Model
{
    protected $table = 'cheat_versions';
    protected $primaryKey = 'id';
    protected $fillable = [
        'version', 'file_path', 'description', 'changelog',
        'is_active', 'required_plan', 'size', 'downloads'
    ];

    // Get all active versions
    public function getActive()
    {
        return $this->where('is_active = 1', []);
    }

    // Get active versions available for a specific plan
    public function getActiveForPlan($plan)
    {
        $plans = $this->getPlanHierarchy($plan);
        $placeholders = implode(',', array_fill(0, count($plans), '?'));

        $sql = "SELECT * FROM {$this->table}
                WHERE is_active = 1
                AND (required_plan IS NULL OR required_plan IN ({$placeholders}))
                ORDER BY created_at DESC";

        return $this->db->select($sql, $plans);
    }

    // Get the latest active version
    public function getLatestActive()
    {
        $sql = "SELECT * FROM {$this->table}
                WHERE is_active = 1
                ORDER BY created_at DESC
                LIMIT 1";

        return $this->db->selectOne($sql);
    }

    // Get the latest active version for a specific plan
    public function getLatestActiveForPlan($plan)
    {
        $plans = $this->getPlanHierarchy($plan);
        $placeholders = implode(',', array_fill(0, count($plans), '?'));

        $sql = "SELECT * FROM {$this->table}
                WHERE is_active = 1
                AND (required_plan IS NULL OR required_plan IN ({$placeholders}))
                ORDER BY created_at DESC
                LIMIT 1";

        return $this->db->selectOne($sql, $plans);
    }

    // Increment the download count
    public function incrementDownloads($id)
    {
        $version = $this->find($id);

        if (!$version) {
            return false;
        }

        $downloads = (int)$version['downloads'] + 1;

        return $this->update($id, [
            'downloads' => $downloads
        ]);
    }

    // Check if a version is newer than another
    public function isNewer($version1, $version2)
    {
        return version_compare($version1, $version2, '>');
    }

    // Check if a cheat version is available for a user's subscription
    public function isAvailableForUser($versionId, $userId)
    {
        $version = $this->find($versionId);

        if (!$version || !$version['is_active']) {
            return false;
        }

        // If the version doesn't require a specific plan, it's available to all users
        if (!$version['required_plan']) {
            return true;
        }

        // Check if the user has an active subscription with the required plan
        $subscriptionModel = new \App\Models\Subscription();
        $subscription = $subscriptionModel->getLatestActiveForUser($userId);

        if (!$subscription) {
            return false;
        }

        // Check if the user's plan is sufficient
        $plans = $this->getPlanHierarchy($subscription['plan']);
        return in_array($version['required_plan'], $plans);
    }

    // Get the plan hierarchy (all plans that are included in the given plan)
    private function getPlanHierarchy($plan)
    {
        $planHierarchy = [
            'basic' => ['basic'],
            'premium' => ['basic', 'premium'],
            'vip' => ['basic', 'premium', 'vip']
        ];

        return $planHierarchy[$plan] ?? [$plan];
    }

    // Save a new version
    public function saveVersion($data, $filePath, $fileSize)
    {
        $data['file_path'] = $filePath;
        $data['size'] = $fileSize;

        return $this->create($data);
    }

    // Activate a version
    public function activate($id)
    {
        return $this->update($id, [
            'is_active' => 1
        ]);
    }

    // Deactivate a version
    public function deactivate($id)
    {
        return $this->update($id, [
            'is_active' => 0
        ]);
    }

    // Get versions with pagination
    public function getVersionsWithPagination($page = 1, $perPage = 10)
    {
        return $this->paginate($page, $perPage, null, [], 'created_at DESC');
    }

    // Get download stats by version
    public function getDownloadStats()
    {
        $sql = "SELECT version, downloads FROM {$this->table} ORDER BY created_at";
        return $this->db->select($sql);
    }

    // Get total downloads
    public function getTotalDownloads()
    {
        $sql = "SELECT SUM(downloads) as total FROM {$this->table}";
        $result = $this->db->selectOne($sql);
        return $result['total'] ?? 0;
    }
}
