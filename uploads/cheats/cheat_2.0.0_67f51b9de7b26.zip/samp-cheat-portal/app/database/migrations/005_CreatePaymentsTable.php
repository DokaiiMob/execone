<?php

namespace App\Database\Migrations;

use App\Core\Migration;

class CreatePaymentsTable extends Migration
{
    public function up()
    {
        if (!$this->tableExists('payments')) {
            $fields = [
                'id' => 'INTEGER NOT NULL',
                'user_id' => 'INTEGER NOT NULL',
                'subscription_id' => 'INTEGER NULL',
                'amount' => 'DECIMAL(10, 2) NOT NULL',
                'currency' => 'VARCHAR(3) NOT NULL DEFAULT "USD"',
                'payment_method' => 'VARCHAR(50) NOT NULL',
                'transaction_id' => 'VARCHAR(255) NULL',
                'status' => 'VARCHAR(20) NOT NULL DEFAULT "pending"',
                'payment_data' => 'TEXT NULL',
                'created_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
                'updated_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP'
            ];

            $this->createTable('payments', $fields, 'id');

            // Add indexes
            $this->addIndex('payments', 'payments_user_id_idx', 'user_id');
            $this->addIndex('payments', 'payments_subscription_id_idx', 'subscription_id');
            $this->addIndex('payments', 'payments_transaction_id_idx', 'transaction_id');
        }
    }

    public function down()
    {
        $this->dropTable('payments');
    }
}
