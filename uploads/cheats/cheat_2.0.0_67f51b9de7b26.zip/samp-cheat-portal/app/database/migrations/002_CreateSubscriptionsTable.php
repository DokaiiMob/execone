<?php

namespace App\Database\Migrations;

use App\Core\Migration;

class CreateSubscriptionsTable extends Migration
{
    public function up()
    {
        if (!$this->tableExists('subscriptions')) {
            $fields = [
                'id' => 'INTEGER NOT NULL',
                'user_id' => 'INTEGER NOT NULL',
                'plan' => 'VARCHAR(50) NOT NULL',
                'status' => 'VARCHAR(20) NOT NULL DEFAULT "active"',
                'starts_at' => 'DATETIME NOT NULL',
                'expires_at' => 'DATETIME NOT NULL',
                'payment_id' => 'VARCHAR(255) NULL',
                'payment_method' => 'VARCHAR(50) NULL',
                'amount_paid' => 'DECIMAL(10, 2) NOT NULL',
                'auto_renew' => 'BOOLEAN NOT NULL DEFAULT 0',
                'created_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
                'updated_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP'
            ];

            $this->createTable('subscriptions', $fields, 'id');

            // Add indexes
            $this->addIndex('subscriptions', 'subscriptions_user_id_idx', 'user_id');
            $this->addIndex('subscriptions', 'subscriptions_expires_at_idx', 'expires_at');
        }
    }

    public function down()
    {
        $this->dropTable('subscriptions');
    }
}
