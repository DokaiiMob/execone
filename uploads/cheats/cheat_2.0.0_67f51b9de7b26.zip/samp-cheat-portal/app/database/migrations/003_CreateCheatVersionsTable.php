<?php

namespace App\Database\Migrations;

use App\Core\Migration;

class CreateCheatVersionsTable extends Migration
{
    public function up()
    {
        if (!$this->tableExists('cheat_versions')) {
            $fields = [
                'id' => 'INTEGER NOT NULL',
                'version' => 'VARCHAR(20) NOT NULL',
                'file_path' => 'VARCHAR(255) NOT NULL',
                'description' => 'TEXT NULL',
                'changelog' => 'TEXT NULL',
                'is_active' => 'BOOLEAN NOT NULL DEFAULT 1',
                'required_plan' => 'VARCHAR(50) NULL',
                'size' => 'INTEGER NULL',
                'downloads' => 'INTEGER NOT NULL DEFAULT 0',
                'created_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
                'updated_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP'
            ];

            $this->createTable('cheat_versions', $fields, 'id');

            // Add indexes
            $this->addIndex('cheat_versions', 'cheat_versions_version_idx', 'version');
        }
    }

    public function down()
    {
        $this->dropTable('cheat_versions');
    }
}
