<?php

namespace App\Database\Migrations;

use App\Core\Migration;

class CreateDownloadsTable extends Migration
{
    public function up()
    {
        if (!$this->tableExists('downloads')) {
            $fields = [
                'id' => 'INTEGER NOT NULL',
                'user_id' => 'INTEGER NOT NULL',
                'cheat_version_id' => 'INTEGER NOT NULL',
                'ip_address' => 'VARCHAR(45) NULL',
                'user_agent' => 'TEXT NULL',
                'hwid' => 'VARCHAR(255) NULL',
                'created_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP'
            ];

            $this->createTable('downloads', $fields, 'id');

            // Add indexes
            $this->addIndex('downloads', 'downloads_user_id_idx', 'user_id');
            $this->addIndex('downloads', 'downloads_cheat_version_id_idx', 'cheat_version_id');
        }
    }

    public function down()
    {
        $this->dropTable('downloads');
    }
}
