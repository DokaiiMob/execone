<?php

namespace App\Database\Migrations;

use App\Core\Migration;

class CreateUsersTable extends Migration
{
    public function up()
    {
        if (!$this->tableExists('users')) {
            $fields = [
                'id' => 'INTEGER NOT NULL',
                'username' => 'VARCHAR(100) NOT NULL',
                'email' => 'VARCHAR(255) NOT NULL',
                'password' => 'VARCHAR(255) NOT NULL',
                'role' => 'VARCHAR(20) NOT NULL DEFAULT "user"',
                'email_verified' => 'BOOLEAN NOT NULL DEFAULT 0',
                'email_verification_token' => 'VARCHAR(100) NULL',
                'password_reset_token' => 'VARCHAR(100) NULL',
                'hwid' => 'VARCHAR(255) NULL',
                'last_login' => 'DATETIME NULL',
                'login_attempts' => 'INTEGER NOT NULL DEFAULT 0',
                'locked_until' => 'DATETIME NULL',
                'created_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
                'updated_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP'
            ];

            $this->createTable('users', $fields, 'id');

            // Add indexes
            $this->addIndex('users', 'users_email_idx', 'email');
            $this->addIndex('users', 'users_username_idx', 'username');
        }
    }

    public function down()
    {
        $this->dropTable('users');
    }
}
