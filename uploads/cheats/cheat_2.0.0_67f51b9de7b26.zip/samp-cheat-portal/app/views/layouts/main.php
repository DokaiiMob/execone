<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? e($title) . ' - ' . e(config('site.name')) : e(config('site.name')) ?></title>
    <meta name="description" content="<?= e(config('site.description')) ?>">

    <!-- Favicon -->
    <link rel="icon" href="<?= asset('assets/img/favicon.ico') ?>" type="image/x-icon">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= asset('assets/css/style.css') ?>">

    <?php if (isset($extraCss)): ?>
        <?= $extraCss ?>
    <?php endif; ?>
</head>
<body class="<?= config('site.theme') === 'dark' ? 'dark-theme' : 'light-theme' ?>">
    <!-- Header -->
    <header class="header">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="<?= url('/') ?>">
                    <img src="<?= asset(config('site.logo')) ?>" alt="<?= e(config('site.name')) ?>" height="40">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link <?= getCurrentUrl() === url('/') ? 'active' : '' ?>" href="<?= url('/') ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= getCurrentUrl() === url('/features') ? 'active' : '' ?>" href="<?= url('/features') ?>">Features</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= getCurrentUrl() === url('/pricing') ? 'active' : '' ?>" href="<?= url('/pricing') ?>">Pricing</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= getCurrentUrl() === url('/about') ? 'active' : '' ?>" href="<?= url('/about') ?>">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= getCurrentUrl() === url('/contact') ? 'active' : '' ?>" href="<?= url('/contact') ?>">Contact</a>
                        </li>
                    </ul>
                    <div class="d-flex">
                        <?php if (isLoggedIn()): ?>
                            <div class="dropdown">
                                <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user me-1"></i> My Account
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                    <li><a class="dropdown-item" href="<?= url('/dashboard') ?>">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?= url('/dashboard/profile') ?>">Profile</a></li>
                                    <li><a class="dropdown-item" href="<?= url('/dashboard/subscription') ?>">Subscription</a></li>
                                    <li><a class="dropdown-item" href="<?= url('/dashboard/downloads') ?>">Downloads</a></li>
                                    <?php if (isAdmin()): ?>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="<?= url('/admin') ?>">Admin Panel</a></li>
                                    <?php endif; ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="<?= url('/logout') ?>">Logout</a></li>
                                </ul>
                            </div>
                        <?php else: ?>
                            <a href="<?= url('/login') ?>" class="btn btn-outline-primary me-2">Login</a>
                            <a href="<?= url('/register') ?>" class="btn btn-primary">Register</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Flash Messages -->
    <?php if ($flash = getFlash('success')): ?>
        <div class="alert alert-success alert-dismissible fade show m-3" role="alert">
            <?= e($flash) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($flash = getFlash('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
            <?= e($flash) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($flash = getFlash('info')): ?>
        <div class="alert alert-info alert-dismissible fade show m-3" role="alert">
            <?= e($flash) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($flash = getFlash('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show m-3" role="alert">
            <?= e($flash) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Main Content -->
    <main class="main-content">
        <?= $content ?>
    </main>

    <!-- Footer -->
    <footer class="footer mt-auto py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>About Us</h5>
                    <p>SAMP Cheat Portal provides high-quality cheats for San Andreas Multiplayer. Our aim is to enhance your gaming experience with safe and undetectable cheats.</p>
                </div>
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?= url('/') ?>">Home</a></li>
                        <li><a href="<?= url('/features') ?>">Features</a></li>
                        <li><a href="<?= url('/pricing') ?>">Pricing</a></li>
                        <li><a href="<?= url('/about') ?>">About</a></li>
                        <li><a href="<?= url('/contact') ?>">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contact Us</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-envelope me-2"></i> <?= e(config('site.email')) ?></li>
                        <li><i class="fas fa-globe me-2"></i> <?= e(config('site.url')) ?></li>
                    </ul>
                    <h5 class="mt-3">Follow Us</h5>
                    <div class="social-icons">
                        <a href="#" class="me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="me-2"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="me-2"><i class="fab fa-discord"></i></a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p>&copy; <?= date('Y') ?> <?= e(config('site.name')) ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Custom JS -->
    <script src="<?= asset('assets/js/main.js') ?>"></script>

    <?php if (isset($extraJs)): ?>
        <?= $extraJs ?>
    <?php endif; ?>
</body>
</html>
