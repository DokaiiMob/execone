<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? e($title) . ' - Admin - ' . e(config('site.name')) : 'Admin - ' . e(config('site.name')) ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?= asset('assets/img/favicon.ico') ?>" type="image/x-icon">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Admin CSS -->
    <link rel="stylesheet" href="<?= asset('assets/css/admin.css') ?>">

    <?php if (isset($extraCss)): ?>
        <?= $extraCss ?>
    <?php endif; ?>
</head>
<body class="admin-panel <?= config('site.theme') === 'dark' ? 'dark-theme' : 'light-theme' ?>">
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="sidebar">
            <div class="sidebar-header">
                <h3><?= e(config('site.name')) ?></h3>
                <div class="sidebar-brand-icon">
                    <img src="<?= asset(config('site.logo')) ?>" alt="Logo" height="40">
                </div>
            </div>

            <ul class="list-unstyled components">
                <li class="<?= getCurrentUrl() === url('/admin') ? 'active' : '' ?>">
                    <a href="<?= url('/admin') ?>">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                </li>
                <li class="<?= strpos(getCurrentUrl(), url('/admin/users')) === 0 ? 'active' : '' ?>">
                    <a href="<?= url('/admin/users') ?>">
                        <i class="fas fa-users me-2"></i> Users
                    </a>
                </li>
                <li class="<?= strpos(getCurrentUrl(), url('/admin/subscriptions')) === 0 ? 'active' : '' ?>">
                    <a href="<?= url('/admin/subscriptions') ?>">
                        <i class="fas fa-credit-card me-2"></i> Subscriptions
                    </a>
                </li>
                <li class="<?= strpos(getCurrentUrl(), url('/admin/versions')) === 0 ? 'active' : '' ?>">
                    <a href="<?= url('/admin/versions') ?>">
                        <i class="fas fa-code me-2"></i> Cheat Versions
                    </a>
                </li>
                <li class="<?= strpos(getCurrentUrl(), url('/admin/payments')) === 0 ? 'active' : '' ?>">
                    <a href="<?= url('/admin/payments') ?>">
                        <i class="fas fa-money-bill-wave me-2"></i> Payments
                    </a>
                </li>
                <li class="<?= strpos(getCurrentUrl(), url('/admin/statistics')) === 0 ? 'active' : '' ?>">
                    <a href="<?= url('/admin/statistics') ?>">
                        <i class="fas fa-chart-line me-2"></i> Statistics
                    </a>
                </li>
                <li class="<?= strpos(getCurrentUrl(), url('/admin/settings')) === 0 ? 'active' : '' ?>">
                    <a href="<?= url('/admin/settings') ?>">
                        <i class="fas fa-cog me-2"></i> Settings
                    </a>
                </li>
                <li>
                    <a href="<?= url('/') ?>">
                        <i class="fas fa-home me-2"></i> Back to Website
                    </a>
                </li>
                <li>
                    <a href="<?= url('/logout') ?>">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Page Content -->
        <div id="content" class="content">
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-primary">
                        <i class="fas fa-bars"></i>
                    </button>

                    <div class="ms-auto d-flex align-items-center">
                        <div class="me-3">
                            <span class="text-muted"><?= date('F j, Y') ?></span>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="adminDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-1"></i> Admin
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="adminDropdown">
                                <li><a class="dropdown-item" href="<?= url('/dashboard/profile') ?>">My Profile</a></li>
                                <li><a class="dropdown-item" href="<?= url('/admin/settings') ?>">Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?= url('/logout') ?>">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Flash Messages -->
            <?php if ($flash = getFlash('success')): ?>
                <div class="alert alert-success alert-dismissible fade show m-3" role="alert">
                    <?= e($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($flash = getFlash('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
                    <?= e($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($flash = getFlash('info')): ?>
                <div class="alert alert-info alert-dismissible fade show m-3" role="alert">
                    <?= e($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($flash = getFlash('warning')): ?>
                <div class="alert alert-warning alert-dismissible fade show m-3" role="alert">
                    <?= e($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Content Container -->
            <div class="container-fluid content-container">
                <?php if (isset($title)): ?>
                    <h1 class="mb-4"><?= e($title) ?></h1>
                <?php endif; ?>

                <?= $content ?>
            </div>

            <!-- Footer -->
            <footer class="footer mt-auto py-3">
                <div class="container-fluid">
                    <div class="text-center">
                        <p>&copy; <?= date('Y') ?> <?= e(config('site.name')) ?> Admin Panel. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Admin JS -->
    <script src="<?= asset('assets/js/admin.js') ?>"></script>

    <script>
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $('#content').toggleClass('active');
            });
        });
    </script>

    <?php if (isset($extraJs)): ?>
        <?= $extraJs ?>
    <?php endif; ?>
</body>
</html>
