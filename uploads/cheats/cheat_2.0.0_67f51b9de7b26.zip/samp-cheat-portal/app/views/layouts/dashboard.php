<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? e($title) . ' - Dashboard - ' . e(config('site.name')) : 'Dashboard - ' . e(config('site.name')) ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?= asset('assets/img/favicon.ico') ?>" type="image/x-icon">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Dashboard CSS -->
    <link rel="stylesheet" href="<?= asset('assets/css/dashboard.css') ?>">

    <?php if (isset($extraCss)): ?>
        <?= $extraCss ?>
    <?php endif; ?>
</head>
<body class="dashboard <?= config('site.theme') === 'dark' ? 'dark-theme' : 'light-theme' ?>">
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="sidebar">
            <div class="sidebar-header">
                <h3><?= e(config('site.name')) ?></h3>
                <div class="sidebar-brand-icon">
                    <img src="<?= asset(config('site.logo')) ?>" alt="Logo" height="40">
                </div>
            </div>

            <ul class="list-unstyled components">
                <li class="<?= getCurrentUrl() === url('/dashboard') ? 'active' : '' ?>">
                    <a href="<?= url('/dashboard') ?>">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                </li>
                <li class="<?= getCurrentUrl() === url('/dashboard/profile') ? 'active' : '' ?>">
                    <a href="<?= url('/dashboard/profile') ?>">
                        <i class="fas fa-user me-2"></i> My Profile
                    </a>
                </li>
                <li class="<?= getCurrentUrl() === url('/dashboard/subscription') ? 'active' : '' ?>">
                    <a href="<?= url('/dashboard/subscription') ?>">
                        <i class="fas fa-credit-card me-2"></i> Subscription
                    </a>
                </li>
                <li class="<?= getCurrentUrl() === url('/dashboard/downloads') ? 'active' : '' ?>">
                    <a href="<?= url('/dashboard/downloads') ?>">
                        <i class="fas fa-download me-2"></i> Downloads
                    </a>
                </li>
                <li class="<?= getCurrentUrl() === url('/dashboard/purchase') ? 'active' : '' ?>">
                    <a href="<?= url('/dashboard/purchase') ?>">
                        <i class="fas fa-shopping-cart me-2"></i> Purchase
                    </a>
                </li>
                <?php if (isAdmin()): ?>
                    <li>
                        <a href="<?= url('/admin') ?>">
                            <i class="fas fa-lock me-2"></i> Admin Panel
                        </a>
                    </li>
                <?php endif; ?>
                <li>
                    <a href="<?= url('/') ?>">
                        <i class="fas fa-home me-2"></i> Back to Website
                    </a>
                </li>
                <li>
                    <a href="<?= url('/logout') ?>">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Page Content -->
        <div id="content" class="content">
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-primary">
                        <i class="fas fa-bars"></i>
                    </button>

                    <div class="ms-auto d-flex align-items-center">
                        <?php
                        // Get user's subscription status
                        $subscriptionModel = new \App\Models\Subscription();
                        $hasActiveSubscription = $subscriptionModel->userHasActiveSubscription(getUserId());
                        $subscription = $subscriptionModel->getLatestActiveForUser(getUserId());
                        $subscriptionBadge = '';

                        if ($hasActiveSubscription && $subscription) {
                            $planName = config("subscription_plans.{$subscription['plan']}.name");
                            $expiresIn = ceil((strtotime($subscription['expires_at']) - time()) / 86400); // days
                            $badgeClass = 'bg-success';

                            if ($expiresIn <= 3) {
                                $badgeClass = 'bg-warning text-dark';
                            }

                            $subscriptionBadge = '<span class="badge ' . $badgeClass . ' me-3">' . e($planName) . ' - ' . $expiresIn . ' days left</span>';
                        } else {
                            $subscriptionBadge = '<span class="badge bg-danger me-3">No Active Subscription</span>';
                        }

                        echo $subscriptionBadge;
                        ?>

                        <div class="dropdown">
                            <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-1"></i> My Account
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="<?= url('/dashboard/profile') ?>">Profile</a></li>
                                <li><a class="dropdown-item" href="<?= url('/dashboard/subscription') ?>">Subscription</a></li>
                                <li><a class="dropdown-item" href="<?= url('/dashboard/downloads') ?>">Downloads</a></li>
                                <?php if (isAdmin()): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="<?= url('/admin') ?>">Admin Panel</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?= url('/logout') ?>">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Flash Messages -->
            <?php if ($flash = getFlash('success')): ?>
                <div class="alert alert-success alert-dismissible fade show m-3" role="alert">
                    <?= e($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($flash = getFlash('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
                    <?= e($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($flash = getFlash('info')): ?>
                <div class="alert alert-info alert-dismissible fade show m-3" role="alert">
                    <?= e($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($flash = getFlash('warning')): ?>
                <div class="alert alert-warning alert-dismissible fade show m-3" role="alert">
                    <?= e($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Content Container -->
            <div class="container-fluid content-container">
                <?php if (isset($title)): ?>
                    <h1 class="mb-4"><?= e($title) ?></h1>
                <?php endif; ?>

                <?= $content ?>
            </div>

            <!-- Footer -->
            <footer class="footer mt-auto py-3">
                <div class="container-fluid">
                    <div class="text-center">
                        <p>&copy; <?= date('Y') ?> <?= e(config('site.name')) ?>. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Dashboard JS -->
    <script src="<?= asset('assets/js/dashboard.js') ?>"></script>

    <script>
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $('#content').toggleClass('active');
            });
        });
    </script>

    <?php if (isset($extraJs)): ?>
        <?= $extraJs ?>
    <?php endif; ?>
</body>
</html>
