<?php

use App\Core\Config;
use App\Core\Database;

if (!function_exists('config')) {
    /**
     * Get a configuration value
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    function config($key = null, $default = null)
    {
        return Config::getInstance()->get($key, $default);
    }
}

if (!function_exists('db')) {
    /**
     * Get the database instance
     *
     * @return \App\Core\Database
     */
    function db()
    {
        return Database::getInstance();
    }
}

if (!function_exists('e')) {
    /**
     * Escape HTML entities
     *
     * @param string $value
     * @return string
     */
    function e($value)
    {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8', false);
    }
}

if (!function_exists('asset')) {
    /**
     * Get the URL for an asset
     *
     * @param string $path
     * @return string
     */
    function asset($path)
    {
        return config('site.url') . '/' . ltrim($path, '/');
    }
}

if (!function_exists('url')) {
    /**
     * Generate a URL for the application
     *
     * @param string $path
     * @return string
     */
    function url($path = '')
    {
        return config('site.url') . '/' . ltrim($path, '/');
    }
}

if (!function_exists('redirect')) {
    /**
     * Redirect to another page
     *
     * @param string $url
     * @param int $statusCode
     * @return void
     */
    function redirect($url, $statusCode = 302)
    {
        header('Location: ' . $url, true, $statusCode);
        exit;
    }
}

if (!function_exists('session')) {
    /**
     * Get / set session values
     *
     * @param string|array|null $key
     * @param mixed $default
     * @return mixed
     */
    function session($key = null, $default = null)
    {
        if (is_null($key)) {
            return $_SESSION;
        }

        if (is_array($key)) {
            foreach ($key as $k => $v) {
                $_SESSION[$k] = $v;
            }
            return null;
        }

        return $_SESSION[$key] ?? $default;
    }
}

if (!function_exists('flash')) {
    /**
     * Flash a message to the session
     *
     * @param string $type
     * @param string $message
     * @return void
     */
    function flash($type, $message)
    {
        $_SESSION['flash'][$type] = $message;
    }
}

if (!function_exists('getFlash')) {
    /**
     * Get flash messages
     *
     * @param string|null $type
     * @return mixed
     */
    function getFlash($type = null)
    {
        if ($type) {
            $flash = $_SESSION['flash'][$type] ?? null;
            unset($_SESSION['flash'][$type]);
            return $flash;
        }

        $flash = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $flash;
    }
}

if (!function_exists('csrf_token')) {
    /**
     * Generate a CSRF token
     *
     * @return string
     */
    function csrf_token()
    {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('verify_csrf_token')) {
    /**
     * Verify CSRF token
     *
     * @param string $token
     * @return bool
     */
    function verify_csrf_token($token)
    {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
}

if (!function_exists('old')) {
    /**
     * Get old input value
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    function old($key, $default = '')
    {
        return $_SESSION['old'][$key] ?? $default;
    }
}

if (!function_exists('validate')) {
    /**
     * Validate input data
     *
     * @param array $data
     * @param array $rules
     * @return array
     */
    function validate($data, $rules)
    {
        $errors = [];

        foreach ($rules as $field => $rule) {
            $ruleList = explode('|', $rule);

            foreach ($ruleList as $singleRule) {
                $params = [];

                if (strpos($singleRule, ':') !== false) {
                    list($ruleName, $ruleParams) = explode(':', $singleRule);
                    $params = explode(',', $ruleParams);
                } else {
                    $ruleName = $singleRule;
                }

                switch ($ruleName) {
                    case 'required':
                        if (!isset($data[$field]) || trim($data[$field]) === '') {
                            $errors[$field][] = 'The ' . $field . ' field is required.';
                        }
                        break;

                    case 'email':
                        if (isset($data[$field]) && !filter_var($data[$field], FILTER_VALIDATE_EMAIL)) {
                            $errors[$field][] = 'The ' . $field . ' must be a valid email address.';
                        }
                        break;

                    case 'min':
                        if (isset($data[$field]) && strlen($data[$field]) < $params[0]) {
                            $errors[$field][] = 'The ' . $field . ' must be at least ' . $params[0] . ' characters.';
                        }
                        break;

                    case 'max':
                        if (isset($data[$field]) && strlen($data[$field]) > $params[0]) {
                            $errors[$field][] = 'The ' . $field . ' may not be greater than ' . $params[0] . ' characters.';
                        }
                        break;

                    case 'matches':
                        if (isset($data[$field]) && isset($data[$params[0]]) && $data[$field] !== $data[$params[0]]) {
                            $errors[$field][] = 'The ' . $field . ' and ' . $params[0] . ' must match.';
                        }
                        break;

                    case 'numeric':
                        if (isset($data[$field]) && !is_numeric($data[$field])) {
                            $errors[$field][] = 'The ' . $field . ' must be a number.';
                        }
                        break;
                }
            }
        }

        if (!empty($errors)) {
            $_SESSION['old'] = $data;
            $_SESSION['errors'] = $errors;
            return false;
        }

        return true;
    }
}

if (!function_exists('errors')) {
    /**
     * Get validation errors
     *
     * @param string|null $field
     * @return mixed
     */
    function errors($field = null)
    {
        if ($field) {
            $errors = $_SESSION['errors'][$field] ?? [];
            unset($_SESSION['errors'][$field]);
            return $errors;
        }

        $errors = $_SESSION['errors'] ?? [];
        unset($_SESSION['errors']);
        return $errors;
    }
}

if (!function_exists('hasError')) {
    /**
     * Check if there is an error for a field
     *
     * @param string $field
     * @return bool
     */
    function hasError($field)
    {
        return isset($_SESSION['errors'][$field]);
    }
}

if (!function_exists('formatDate')) {
    /**
     * Format a date
     *
     * @param string $date
     * @param string $format
     * @return string
     */
    function formatDate($date, $format = 'Y-m-d H:i:s')
    {
        return date($format, strtotime($date));
    }
}

if (!function_exists('getCurrentUrl')) {
    /**
     * Get the current URL
     *
     * @return string
     */
    function getCurrentUrl()
    {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }
}

if (!function_exists('generateRandomString')) {
    /**
     * Generate a random string
     *
     * @param int $length
     * @return string
     */
    function generateRandomString($length = 16)
    {
        return bin2hex(random_bytes(intval($length / 2)));
    }
}

if (!function_exists('isLoggedIn')) {
    /**
     * Check if the user is logged in
     *
     * @return bool
     */
    function isLoggedIn()
    {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('isAdmin')) {
    /**
     * Check if the user is an admin
     *
     * @return bool
     */
    function isAdmin()
    {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
}

if (!function_exists('getUserId')) {
    /**
     * Get the current user ID
     *
     * @return int|null
     */
    function getUserId()
    {
        return $_SESSION['user_id'] ?? null;
    }
}

if (!function_exists('dump')) {
    /**
     * Dump a variable
     *
     * @param mixed $var
     * @return void
     */
    function dump($var)
    {
        echo '<pre>';
        var_dump($var);
        echo '</pre>';
    }
}

if (!function_exists('dd')) {
    /**
     * Dump a variable and die
     *
     * @param mixed $var
     * @return void
     */
    function dd($var)
    {
        dump($var);
        die;
    }
}
