<?php
/**
 * Main Configuration File
 *
 * This file contains all main settings for the SAMP Cheat Portal
 */

return [
    // Site Configuration
    'site' => [
        'name' => 'SAMP Cheat Portal',
        'description' => 'The best cheats for San Andreas Multiplayer',
        'url' => 'https://example.com',
        'email' => 'admin@example.com',
        'logo' => '/assets/img/logo.png',
        'theme' => 'dark', // dark or light
        'language' => 'en', // en, ru, etc.
        'timezone' => 'UTC',
        'debug' => true, // set to false in production
    ],

    // Database Configuration
    'database' => [
        'type' => 'sqlite', // 'mysql' or 'sqlite'

        // MySQL settings (used if type is mysql)
        'mysql' => [
            'host' => 'localhost',
            'database' => 'samp_cheat_portal',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'port' => 3306
        ],

        // SQLite settings (used if type is sqlite)
        'sqlite' => [
            'database' => __DIR__ . '/../../database/database.sqlite',
            'prefix' => '',
            'foreign_key_constraints' => true
        ]
    ],

    // Authentication settings
    'auth' => [
        'session_lifetime' => 86400, // 24 hours
        'remember_me_lifetime' => 2592000, // 30 days
        'password_reset_timeout' => 3600, // 1 hour
        'require_email_verification' => true,
        'max_login_attempts' => 5,
        'lockout_time' => 300, // 5 minutes
    ],

    // Subscription Plans
    'subscription_plans' => [
        'basic' => [
            'name' => 'Basic',
            'price' => 5.99,
            'duration' => 30, // days
            'features' => [
                'Basic cheat access',
                'Standard support',
                'Weekly updates',
            ]
        ],
        'premium' => [
            'name' => 'Premium',
            'price' => 12.99,
            'duration' => 30, // days
            'features' => [
                'Advanced cheat features',
                'Priority support',
                'Daily updates',
                'Anti-detection system',
            ]
        ],
        'vip' => [
            'name' => 'VIP',
            'price' => 24.99,
            'duration' => 30, // days
            'features' => [
                'All cheat features',
                '24/7 support',
                'Real-time updates',
                'Advanced anti-detection system',
                'Custom features',
                'Private forum access',
            ]
        ]
    ],

    // Payment Gateways
    'payment' => [
        'currency' => 'USD',
        'payment_methods' => [
            'paypal' => [
                'enabled' => true,
                'client_id' => 'YOUR_PAYPAL_CLIENT_ID',
                'client_secret' => 'YOUR_PAYPAL_CLIENT_SECRET',
                'sandbox' => true, // set to false in production
            ],
            'stripe' => [
                'enabled' => true,
                'public_key' => 'YOUR_STRIPE_PUBLIC_KEY',
                'secret_key' => 'YOUR_STRIPE_SECRET_KEY',
                'webhook_secret' => 'YOUR_STRIPE_WEBHOOK_SECRET',
                'test_mode' => true, // set to false in production
            ],
            'crypto' => [
                'enabled' => true,
                'bitcoin_address' => 'YOUR_BITCOIN_ADDRESS',
                'ethereum_address' => 'YOUR_ETHEREUM_ADDRESS',
            ]
        ]
    ],

    // Admin settings
    'admin' => [
        'email' => 'admin@example.com',
        'enable_2fa' => true,
        'log_all_actions' => true,
        'notification_email' => 'admin@example.com',
    ],

    // Security settings
    'security' => [
        'csrf_protection' => true,
        'session_encryption' => true,
        'hash_algo' => PASSWORD_BCRYPT,
        'hash_options' => ['cost' => 12],
        'xss_protection' => true,
        'allowed_html_tags' => '<p><br><a><strong><em><ul><ol><li><blockquote><code><pre>',
    ],

    // Cheat settings
    'cheat' => [
        'download_path' => __DIR__ . '/../../storage/cheats/',
        'auto_update' => true,
        'update_frequency' => 'daily', // daily, weekly
        'version_check_url' => 'https://example.com/api/version',
        'hwid_lock' => true,
        'max_activations' => 2,
    ],

    // Logging
    'logging' => [
        'enabled' => true,
        'path' => __DIR__ . '/../../storage/logs/',
        'level' => 'debug', // debug, info, warning, error, critical
    ],
];
