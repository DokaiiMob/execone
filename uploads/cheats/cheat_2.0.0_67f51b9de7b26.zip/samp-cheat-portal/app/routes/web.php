<?php

use App\Core\App;

$router = App::getInstance()->getRouter();

/**
 * Public routes
 */
$router->get('/', 'App\Controllers\HomeController@index');
$router->get('/about', 'App\Controllers\HomeController@about');
$router->get('/features', 'App\Controllers\HomeController@features');
$router->get('/pricing', 'App\Controllers\HomeController@pricing');
$router->get('/contact', 'App\Controllers\HomeController@contact');
$router->post('/contact', 'App\Controllers\HomeController@submitContact');

/**
 * Authentication routes
 */
$router->get('/login', 'App\Controllers\AuthController@loginForm');
$router->post('/login', 'App\Controllers\AuthController@login');
$router->get('/register', 'App\Controllers\AuthController@registerForm');
$router->post('/register', 'App\Controllers\AuthController@register');
$router->get('/logout', 'App\Controllers\AuthController@logout');
$router->get('/forgot-password', 'App\Controllers\AuthController@forgotPasswordForm');
$router->post('/forgot-password', 'App\Controllers\AuthController@forgotPassword');
$router->get('/reset-password/{token}', 'App\Controllers\AuthController@resetPasswordForm');
$router->post('/reset-password', 'App\Controllers\AuthController@resetPassword');
$router->get('/verify-email/{token}', 'App\Controllers\AuthController@verifyEmail');
$router->get('/resend-verification', 'App\Controllers\AuthController@resendVerificationForm');
$router->post('/resend-verification', 'App\Controllers\AuthController@resendVerification');

/**
 * User dashboard routes
 */
$router->get('/dashboard', 'App\Controllers\DashboardController@index');
$router->get('/dashboard/profile', 'App\Controllers\DashboardController@profile');
$router->post('/dashboard/profile', 'App\Controllers\DashboardController@updateProfile');
$router->get('/dashboard/subscription', 'App\Controllers\DashboardController@subscription');
$router->get('/dashboard/downloads', 'App\Controllers\DashboardController@downloads');
$router->get('/dashboard/download/{version}', 'App\Controllers\DashboardController@download');
$router->post('/dashboard/hwid', 'App\Controllers\DashboardController@updateHWID');
$router->get('/dashboard/purchase', 'App\Controllers\DashboardController@purchaseForm');
$router->post('/dashboard/purchase', 'App\Controllers\DashboardController@purchase');
$router->get('/dashboard/payment-success', 'App\Controllers\DashboardController@paymentSuccess');
$router->get('/dashboard/payment-cancel', 'App\Controllers\DashboardController@paymentCancel');

/**
 * Admin routes
 */
$router->get('/admin', 'App\Controllers\Admin\DashboardController@index');

// User management
$router->get('/admin/users', 'App\Controllers\Admin\UserController@index');
$router->get('/admin/users/create', 'App\Controllers\Admin\UserController@create');
$router->post('/admin/users/create', 'App\Controllers\Admin\UserController@store');
$router->get('/admin/users/edit/{id}', 'App\Controllers\Admin\UserController@edit');
$router->post('/admin/users/edit/{id}', 'App\Controllers\Admin\UserController@update');
$router->get('/admin/users/delete/{id}', 'App\Controllers\Admin\UserController@delete');
$router->post('/admin/users/delete/{id}', 'App\Controllers\Admin\UserController@destroy');

// Subscription management
$router->get('/admin/subscriptions', 'App\Controllers\Admin\SubscriptionController@index');
$router->get('/admin/subscriptions/create', 'App\Controllers\Admin\SubscriptionController@create');
$router->post('/admin/subscriptions/create', 'App\Controllers\Admin\SubscriptionController@store');
$router->get('/admin/subscriptions/edit/{id}', 'App\Controllers\Admin\SubscriptionController@edit');
$router->post('/admin/subscriptions/edit/{id}', 'App\Controllers\Admin\SubscriptionController@update');
$router->get('/admin/subscriptions/delete/{id}', 'App\Controllers\Admin\SubscriptionController@delete');
$router->post('/admin/subscriptions/delete/{id}', 'App\Controllers\Admin\SubscriptionController@destroy');

// Cheat version management
$router->get('/admin/versions', 'App\Controllers\Admin\VersionController@index');
$router->get('/admin/versions/create', 'App\Controllers\Admin\VersionController@create');
$router->post('/admin/versions/create', 'App\Controllers\Admin\VersionController@store');
$router->get('/admin/versions/edit/{id}', 'App\Controllers\Admin\VersionController@edit');
$router->post('/admin/versions/edit/{id}', 'App\Controllers\Admin\VersionController@update');
$router->get('/admin/versions/delete/{id}', 'App\Controllers\Admin\VersionController@delete');
$router->post('/admin/versions/delete/{id}', 'App\Controllers\Admin\VersionController@destroy');

// Payment management
$router->get('/admin/payments', 'App\Controllers\Admin\PaymentController@index');
$router->get('/admin/payments/{id}', 'App\Controllers\Admin\PaymentController@show');
$router->post('/admin/payments/{id}/update-status', 'App\Controllers\Admin\PaymentController@updateStatus');

// Settings
$router->get('/admin/settings', 'App\Controllers\Admin\SettingController@index');
$router->post('/admin/settings', 'App\Controllers\Admin\SettingController@update');

// Statistics
$router->get('/admin/statistics', 'App\Controllers\Admin\StatisticsController@index');
$router->get('/admin/statistics/subscriptions', 'App\Controllers\Admin\StatisticsController@subscriptions');
$router->get('/admin/statistics/downloads', 'App\Controllers\Admin\StatisticsController@downloads');
$router->get('/admin/statistics/payments', 'App\Controllers\Admin\StatisticsController@payments');

/**
 * API routes
 */
$router->mount('/api', function() use ($router) {
    // Get cheat versions
    $router->get('/versions', 'App\Controllers\Api\VersionController@index');

    // Check for updates
    $router->post('/check-update', 'App\Controllers\Api\VersionController@checkUpdate');

    // Subscription status
    $router->post('/subscription-status', 'App\Controllers\Api\SubscriptionController@status');

    // Validate HWID
    $router->post('/validate-hwid', 'App\Controllers\Api\AuthController@validateHWID');

    // Payment webhooks
    $router->post('/webhooks/paypal', 'App\Controllers\Api\WebhookController@paypal');
    $router->post('/webhooks/stripe', 'App\Controllers\Api\WebhookController@stripe');
    $router->post('/webhooks/crypto', 'App\Controllers\Api\WebhookController@crypto');
});
