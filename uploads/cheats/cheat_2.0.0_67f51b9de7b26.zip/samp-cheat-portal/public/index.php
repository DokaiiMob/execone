<?php

/**
 * SAMP Cheat Portal
 * Main Entry Point
 */

// Define the root path
define('ROOT_PATH', dirname(__DIR__));

// Load Composer autoloader
require ROOT_PATH . '/vendor/autoload.php';

// Load environment variables if exists
if (file_exists(ROOT_PATH . '/.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(ROOT_PATH);
    $dotenv->load();
}

// Initialize the application
$app = App\Core\App::getInstance();

// Register all routes
$app->registerRoutes();

// Run the application
$app->run();
