</main>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5 class="mb-3"><?= $config['site']['name'] ?></h5>
                    <p><?= $config['site']['description'] ?></p>
                    <p class="mb-0">
                        <a href="https://vk.com/" target="_blank" class="text-white me-2"><i class="fab fa-vk fa-lg"></i></a>
                        <a href="https://t.me/" target="_blank" class="text-white me-2"><i class="fab fa-telegram fa-lg"></i></a>
                        <a href="https://discord.com/" target="_blank" class="text-white me-2"><i class="fab fa-discord fa-lg"></i></a>
                    </p>
                </div>
                <div class="col-md-4 mb-3">
                    <h5 class="mb-3">Навигация</h5>
                    <ul class="list-unstyled">
                        <li><a href="/" class="text-white text-decoration-none"><i class="fas fa-angle-right me-1"></i> Главная</a></li>
                        <li><a href="/subscription.php" class="text-white text-decoration-none"><i class="fas fa-angle-right me-1"></i> Подписки</a></li>
                        <li><a href="/downloads.php" class="text-white text-decoration-none"><i class="fas fa-angle-right me-1"></i> Скачать чит</a></li>
                        <li><a href="/faq.php" class="text-white text-decoration-none"><i class="fas fa-angle-right me-1"></i> FAQ</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h5 class="mb-3">Контакты</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-envelope me-2"></i> support@example.com</li>
                        <li><i class="fab fa-telegram me-2"></i> @support_bot</li>
                        <li><i class="fas fa-globe me-2"></i> <?= $_SERVER['SERVER_NAME'] ?? 'example.com' ?></li>
                    </ul>
                </div>
            </div>
            <hr class="my-3">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; <?= date('Y') ?> <?= $config['site']['name'] ?>. Все права защищены.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0">Версия: <?= $config['site']['version'] ?></p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
